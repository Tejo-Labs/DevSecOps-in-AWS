public class Config {
    public static int BLOCK_SIZE = 1024;
    public static final int MODE_SAMPLE = 0;
    public static final int MODE_EFS = 1;


    public static int MODE = MODE_SAMPLE;
    //public static int MODE = MODE_EFS;
}
