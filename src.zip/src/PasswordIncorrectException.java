public class PasswordIncorrectException extends Exception{
    public PasswordIncorrectException()
    {
        super();
    }
}
